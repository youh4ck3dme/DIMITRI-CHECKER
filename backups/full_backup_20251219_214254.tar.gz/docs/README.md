# 📚 ILUMINATE SYSTEM - Dokumentácia

Tento priečinok obsahuje všetku dokumentáciu projektu.

## 📄 Dokumenty

- **DESIGN_UPGRADE_PROMPT.md** - Prompt pre vylepšenie landing page
- **SERVER_STATUS.md** - Status serverov a inštrukcie
- **TEST_ICO_GUIDE.md** - Príručka pre testovacie IČO 88888888
- **TEST_REPORT.md** - Výsledky základných testov

## 🔗 Hlavná dokumentácia

Hlavný README.md sa nachádza v root adresári projektu.

